package dimigo.MemberControl;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MemberControlApplication {

	public static void main(String[] args) {
		SpringApplication.run(MemberControlApplication.class, args);
	}

}
